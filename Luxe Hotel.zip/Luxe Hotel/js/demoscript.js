(function(){
    var bsa = document.createElement('script');
    bsa.type = 'text/javascript';
    bsa.async = false;
    bsa.src = '//m.servedby-buysellads.com/monetization.js';
    (document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);
})();
var boxScript = document.createElement('script');
boxScript.text = 'window.onload = function(){if(typeof _bsa !== \'undefined\' && _bsa){_bsa.init(\'stickybox\', \'CKYDL2QY\', \'placement:freehtml5co\');}};';
document.body.appendChild(boxScript);